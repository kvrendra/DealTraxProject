import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deallog',
  templateUrl: './deallog.component.html',
  styleUrls: ['./deallog.component.scss']
})
export class DeallogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
