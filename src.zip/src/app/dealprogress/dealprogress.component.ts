import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealprogress',
  templateUrl: './dealprogress.component.html',
  styleUrls: ['./dealprogress.component.scss']
})
export class DealprogressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
