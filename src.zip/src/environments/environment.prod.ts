export const environment = {
  production: true,
  apiUrl:"https://devtraxapi.axelautomotive.com/api/"
};
