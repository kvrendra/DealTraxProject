import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
// import {PopupComponent} from '../popup/popup.component';
// import { MatDialog } from '@angular/material/dialog';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {

  // dummy:boolean=false;
  closeResult: string = '';
  tempData:any=[
    {
      trackingSteps:"Post-Delivery Inspection",
      Include:"true",
      Sequence:"1",
      dependencies:"Temp Tag",
      notifications:"sales person",
      within:"2 days",
      type:"automatic",
      dmsEvidence:"Generally The Deal Date – There Should Be A Service Record For The PDI (Post-Delivery, Not Pre-Delivery)",
      status:"Active"
    },
    {
      trackingSteps:"pre-Delivery Inspection",
      Include:"true",
      Sequence:"2",
      dependencies:"Temp Tag",
      notifications:"sales person",
      within:"5 days",
      type:"automatic",
      dmsEvidence:"Generally The Deal Date – There Should Be A Service Record For The PDI (Post-Delivery, Not Pre-Delivery)",
      status:"Active"
    },
    {
      trackingSteps:"pre-Delivery ",
      Include:"false",
      Sequence:"3",
      dependencies:"Temp Tag",
      notifications:"controller",
      within:"7 days",
      type:"manual",
      dmsEvidence:"Generally The Deal Date – There Should Be A Service Record For The PDI (Post-Delivery, Not Pre-Delivery)",
      status:"In Active"
    }
  ]
  

  constructor(private modalService: NgbModal
  ) { }

  ngOnInit(): void {
  }


  settingForm = new FormGroup({
    trackingSteps: new FormControl(),
    include: new FormControl(),
    sequence: new FormControl(),
    dependencies: new FormControl(),
    notifications: new FormControl(),
    within: new FormControl(),
    type: new FormControl(),
    dmsEvidence: new FormControl(),
  });
  addSetting()
  {

  }

  EditRow(content: any) {
    this.modalService.open(content)

  }
  DeleteRow() {

  }

  open(content: any) {
    // this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    //   this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });
    this.modalService.open(content)
  }


  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return  `with: ${reason}`;
  //   }
  // }

  close() {
    this.modalService.dismissAll();
  }



}
